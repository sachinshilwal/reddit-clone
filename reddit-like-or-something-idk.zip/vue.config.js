module.exports = {
    publicPath: ''
  }