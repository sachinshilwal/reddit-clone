module.exports = {
  rules: {
    'no-unused-expressions': 'off'
  }
}
